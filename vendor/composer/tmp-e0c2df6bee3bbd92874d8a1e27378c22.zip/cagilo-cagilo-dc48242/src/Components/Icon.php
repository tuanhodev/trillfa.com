<?php

declare(strict_types=1);

namespace Cagilo\UI\Components;

use Orchid\Icons\IconComponent as OrchidIcon;

class Icon extends OrchidIcon
{
}
