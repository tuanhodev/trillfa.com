{!! (new \Orchid\Icons\Icon($html))->setAttributes($data) !!}
