<x-orchid-icon path="{{ str_repeat('a', 9999999) }}" class="icon-big" width="2em" height="2em" />
