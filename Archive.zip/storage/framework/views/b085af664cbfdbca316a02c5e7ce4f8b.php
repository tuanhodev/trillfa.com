<div <?php echo e($attributes); ?>><?php echo $toHtml($slot); ?></div>
<?php /**PATH /home/anh/DEV/www/trillfa/vendor/spatie/laravel-markdown/src/../resources/views/markdown.blade.php ENDPATH**/ ?>