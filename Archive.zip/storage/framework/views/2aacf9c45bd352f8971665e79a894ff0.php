<svg xmlns="http://www.w3.org/2000/svg" width="0.4em" height="0.4em" fill="currentColor" class="bi bi-circle-fill" viewBox="0 0 16 16" role="img" path="bs.circle-fill" componentName="orchid-icon">
  <circle cx="8" cy="8" r="8"></circle>
</svg>
<?php /**PATH /home/anh/DEV/www/trillfa/storage/framework/views/d6f74127dea10f6606d4a009639f5ec7.blade.php ENDPATH**/ ?>