<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('platform.slug-generate', []);

$__html = app('livewire')->mount($__name, $__params, 'DNn7Mdt', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/platform/template/post-title.blade.php ENDPATH**/ ?>