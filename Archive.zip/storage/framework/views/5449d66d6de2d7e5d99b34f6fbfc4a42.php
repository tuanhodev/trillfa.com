<svg xmlns="http://www.w3.org/2000/svg" width="2rem" height="2rem" fill="currentColor" class="bi bi-caret-up-fill" viewBox="0 0 16 16" role="img" path="caret-up-fill" componentName="orchid-icon">
  <path d="m7.247 4.86-4.796 5.481c-.566.647-.106 1.659.753 1.659h9.592a1 1 0 0 0 .753-1.659l-4.796-5.48a1 1 0 0 0-1.506 0z"></path>
</svg>
<?php /**PATH /home/anh/DEV/www/trillfa/storage/framework/views/d834f7bb0db4589880f36ddd55e62079.blade.php ENDPATH**/ ?>