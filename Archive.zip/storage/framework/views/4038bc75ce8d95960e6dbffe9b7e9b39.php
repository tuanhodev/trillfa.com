<div <?php echo e($attributes); ?>>
    <?php echo e($title ?? 'Thanh tiêu đề'); ?>

</div>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/platform/fields/text-field.blade.php ENDPATH**/ ?>