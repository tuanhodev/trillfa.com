<div class="text-center user-select-none my-4 d-none d-lg-block">
    <p class="small mb-0">
        <?php echo e(__('Trang quản trị nôi dung được phát triển từ')); ?> tháng 10 - <?php echo e(date('Y')); ?> bởi Anh Tuấn Dev<br>
        <a href="http://tuanhodev.github.io" target="_blank" rel="noopener">
            tuanhodev
        </a>
    </p>
</div>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/platform/footer.blade.php ENDPATH**/ ?>