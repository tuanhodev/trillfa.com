<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([ 'homeSlider' ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([ 'homeSlider' ]); ?>
<?php foreach (array_filter(([ 'homeSlider' ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($homeSlider): ?>
<section class="home-hero-container">

    <div class="home-hero">

        <div class="hero-header-container">
            <div class="card-base box">
                <a class="hero-header" href="<?php echo e(url($homeSlider->route)); ?>">
                    <h1 class="hero-title"><?php echo e($homeSlider->title); ?></h1>
                </a>
                <p class="hero-desc">
                    <?php echo $homeSlider->builderWord(22); ?>

                </p>
            </div>
        </div>

        <a class="hero-img" href="<?php echo e(url($homeSlider->route)); ?>">
            <img src="<?php echo e(asset($homeSlider->cover->url())); ?>" alt="">
        </a>

    </div>

</section>
<?php endif; ?>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/components/partials/header.blade.php ENDPATH**/ ?>