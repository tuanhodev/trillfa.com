

<?php if (isset($component)) { $__componentOriginalfa710ee477a7171fb238cadd060c5959 = $component; } ?>
<?php $component = App\View\Components\Layouts\App::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layouts\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('pageTitle', null, []); ?> 
        <?php echo e(config('settings.ten-thuong-hieu') . ' | ' . 'Giới thiệu'); ?>

     <?php $__env->endSlot(); ?>

    <article class="about-container container mx-auto"> 

        <header class="cover">

            <div class="img">
                <img src="<?php echo e(asset('images/truyenthong/truyenthong-default.png')); ?>" alt="">
            </div>

            <div class="summary-container">
                <div class="summary">

                    <div class="trillium">
                        <img src="<?php echo e(asset('images/brand/trillium.png')); ?>" alt="">
                    </div>

                    <h3>Trill Studio có phải là một thương hiệu thời trang ?</h3>

                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, et. 
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                    </p>

                </div>
            </div>

        </header>

        <div class="about-content-container">

            <div class="about-content">
                <div class="about">

                    <div class="red-trillium">
                        <img src="<?php echo e(asset('images/brand/red_trillium.png')); ?>" alt="">
                    </div>

                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, et. 
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, et. 
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                        Natus, dolores tempora qui tempore deleniti consequuntur deserunt rem cum.
                    </p>
                </div>
            </div>

            <div class="contact-container">
                <div class="contact">
                    <div class="contact-item">
                        <?php if (isset($component)) { $__componentOriginal385240e1db507cd70f0facab99c4d015 = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'bs.geo-alt'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal385240e1db507cd70f0facab99c4d015)): ?>
<?php $component = $__componentOriginal385240e1db507cd70f0facab99c4d015; ?>
<?php unset($__componentOriginal385240e1db507cd70f0facab99c4d015); ?>
<?php endif; ?>
                        <p>Địa chỉ: <?php echo e(config('settings.dia-chi')); ?></p>
                    </div>
                    <div class="contact-item">
                        <?php if (isset($component)) { $__componentOriginal385240e1db507cd70f0facab99c4d015 = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'bs.envelope'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal385240e1db507cd70f0facab99c4d015)): ?>
<?php $component = $__componentOriginal385240e1db507cd70f0facab99c4d015; ?>
<?php unset($__componentOriginal385240e1db507cd70f0facab99c4d015); ?>
<?php endif; ?>
                        <p>Email: <?php echo e(config('settings.email')); ?></p>
                    </div>
                    <div class="contact-item">
                        <?php if (isset($component)) { $__componentOriginal385240e1db507cd70f0facab99c4d015 = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'bs.telephone'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal385240e1db507cd70f0facab99c4d015)): ?>
<?php $component = $__componentOriginal385240e1db507cd70f0facab99c4d015; ?>
<?php unset($__componentOriginal385240e1db507cd70f0facab99c4d015); ?>
<?php endif; ?>
                        <p>SĐT: <?php echo e(config('settings.so-dien-thoai')); ?></p>
                    </div>
                    <div class="contact-item">
                        <div class="zalo-icon">ZL</div>
                        <p><?php echo e(config('settings.so-dien-thoai')); ?></p>
                    </div>
                </div>
            </div>
        </div>

    </article>

    <div class="footer-header"> </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa710ee477a7171fb238cadd060c5959)): ?>
<?php $component = $__componentOriginalfa710ee477a7171fb238cadd060c5959; ?>
<?php unset($__componentOriginalfa710ee477a7171fb238cadd060c5959); ?>
<?php endif; ?>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/page/about.blade.php ENDPATH**/ ?>