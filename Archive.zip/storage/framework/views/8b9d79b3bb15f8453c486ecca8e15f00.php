<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="msapplication-TileColor" content="#7bc916">

    
    <?php if (isset($component)) { $__componentOriginalabda002dcb857e7f5b19235d0e74405d = $component; } ?>
<?php $component = Cagilo\UI\Components\Meta::resolve(['description' => $metaDes ?? config('settings.description'),'title' => $pageTitle ?? config('app.name'),'image' => $metaImg ?? asset('/favicon.svg'),'card' => $metaImg ?? asset('/favicon.svg')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Cagilo\UI\Components\Meta::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabda002dcb857e7f5b19235d0e74405d)): ?>
<?php $component = $__componentOriginalabda002dcb857e7f5b19235d0e74405d; ?>
<?php unset($__componentOriginalabda002dcb857e7f5b19235d0e74405d); ?>
<?php endif; ?>

    <!-- Favicon -->
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
    <link rel="icon" type="image/svg+xml" sizes="any" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="icon" type="image/svg+xml" sizes="64x64" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="icon" type="image/svg+xml" sizes="32x32" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="icon" type="image/svg+xml" sizes="16x16" href="<?php echo e(asset('/favicon.svg')); ?>">

    <!-- Favicon apply-touch -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/favicon.svg')); ?>">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#7bc916">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/theme/theme.css', 'resources/css/styles.css', 'resources/js/app.js']); ?>

    <!-- Scripts -->
    <?php echo $__env->yieldPushContent('atd-scripts'); ?>

</head>

<body class="surface">

    <div 
        x-data="{ showOnScroll: false }" 
        x-on:scroll.window="showOnScroll = window.pageYOffset >= 1000"
        id="app" class=" min-h-screen">

        <!-- Navigation Bar -->
        <?php if (isset($component)) { $__componentOriginala2bb6a6544012d1b87e35b7604d01f8f = $component; } ?>
<?php $component = App\View\Components\Partials\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2bb6a6544012d1b87e35b7604d01f8f)): ?>
<?php $component = $__componentOriginala2bb6a6544012d1b87e35b7604d01f8f; ?>
<?php unset($__componentOriginala2bb6a6544012d1b87e35b7604d01f8f); ?>
<?php endif; ?>

        <div class="padding-navbar"></div>

        <?php if(request()->routeIs('home')): ?>
        <?php if (isset($component)) { $__componentOriginalc0c11a66fedda4941e253e3a87fe17f7 = $component; } ?>
<?php $component = App\View\Components\MainMenu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainMenu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0c11a66fedda4941e253e3a87fe17f7)): ?>
<?php $component = $__componentOriginalc0c11a66fedda4941e253e3a87fe17f7; ?>
<?php unset($__componentOriginalc0c11a66fedda4941e253e3a87fe17f7); ?>
<?php endif; ?>
        <?php endif; ?>

        <!-- Page Heading -->
        <?php if(isset($header)): ?>
        <header> <?php echo e($header); ?> </header>
        <?php endif; ?>

        <!-- Page Content -->
        <main> <?php echo e($slot); ?> </main>

        <!-- Page footer -->
        <?php if (isset($component)) { $__componentOriginal26f3b41f18b78c8e548c0fac8d469f94 = $component; } ?>
<?php $component = App\View\Components\Partials\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26f3b41f18b78c8e548c0fac8d469f94)): ?>
<?php $component = $__componentOriginal26f3b41f18b78c8e548c0fac8d469f94; ?>
<?php unset($__componentOriginal26f3b41f18b78c8e548c0fac8d469f94); ?>
<?php endif; ?>

        <button 
            x-on:click="window.scrollTo({top: 0, behavior: 'smooth'})"
            x-cloak x-show="showOnScroll"
            x-transition.origin.bottom.duration.500ms 
            class="back-to-top">
            <?php if (isset($component)) { $__componentOriginal385240e1db507cd70f0facab99c4d015 = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'caret-up-fill','width' => '1.5rem','height' => '1.5rem'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal385240e1db507cd70f0facab99c4d015)): ?>
<?php $component = $__componentOriginal385240e1db507cd70f0facab99c4d015; ?>
<?php unset($__componentOriginal385240e1db507cd70f0facab99c4d015); ?>
<?php endif; ?>
        </button>

    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>

</body>

</html>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>