<title><?php echo $title; ?></title>


<meta name="title" content="<?php echo $title; ?>">
<meta name="description" content="<?php echo $description; ?>">

<?php if(empty(!$keywords)): ?>
<meta name="keywords" content="<?php echo $keywords; ?>">
<?php endif; ?>

<?php if(empty(!$author)): ?>
<meta name="author" content="<?php echo $author; ?>">
<?php endif; ?>

<?php if(empty(!$robots)): ?>
<meta name="robots" content="<?php echo $robots; ?>">
<?php endif; ?>

<?php if(empty(!$csp)): ?>
<meta http-equiv="Content-Security-Policy" content="default-src 'self' data: 'unsafe-inline' 'unsafe-hashes' 'unsafe-eval' <?php echo $csp; ?>">
<?php endif; ?>


<meta property="og:type" content="<?php echo $type; ?>">
<meta property="og:url" content="<?php echo $url; ?>"/>
<meta property="og:locale" content="<?php echo app()->getLocale(); ?>"/>
<meta property="og:title" content="<?php echo $title; ?>"/>
<meta property="og:description" content="<?php echo $description; ?>">
<meta property="og:image" content="<?php echo $image; ?>">


<meta name="twitter:card" content="<?php echo $card; ?>"/>
<meta name="twitter:url" content="<?php echo $url; ?>">
<meta name="twitter:title" content="<?php echo $title; ?>">
<meta name="twitter:description" content="<?php echo $description; ?>">
<meta name="twitter:image" content="<?php echo $image; ?>">
<?php /**PATH /home/anh/DEV/www/trillfa/vendor/cagilo/cagilo/src/../resources/views/meta.blade.php ENDPATH**/ ?>