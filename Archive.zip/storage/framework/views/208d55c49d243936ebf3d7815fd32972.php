<div data-controller="browsing" class="mb-3">
    <iframe <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key); ?>='<?php echo e($value); ?>' <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>></iframe>
</div>
<?php /**PATH /home/anh/DEV/www/trillfa/vendor/orchid/platform/resources/views/layouts/browsing.blade.php ENDPATH**/ ?>