<?php if(isset($post)): ?>
<figure class="figure">

    <img class="figure-img img-fluid rounded" src="<?php echo e(asset( $post->cover->url() )); ?>" alt="<?php echo e($post->title); ?>">

    <figcaption class="figure-caption text-center"><?php echo e($post->id); ?></figcaption>

</figure>
<?php endif; ?>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/components/platform/render-image-in-table.blade.php ENDPATH**/ ?>