<div class="row">
    <div class="col-8 border-right">
        <?php $__currentLoopData = $mainContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $content; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-4 no-gutter">
        <?php $__currentLoopData = $rightBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $bar; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/platform/template/content-container.blade.php ENDPATH**/ ?>