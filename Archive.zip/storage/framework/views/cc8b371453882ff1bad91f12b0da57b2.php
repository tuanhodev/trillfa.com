<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" class="me-2" viewBox="0 0 16 16" role="img" path="bs.plus-lg" componentName="orchid-icon">
  <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"></path>
</svg>
<?php /**PATH /home/anh/DEV/www/trillfa/storage/framework/views/f6aace22cdf7daa46e38d8e33ac70885.blade.php ENDPATH**/ ?>