<section class="home-hero-container">

    <div class="container home-hero mx-auto">

        <div class="hero-header-container">
            <a class="hero-header" href="<?php echo e(route($homeSlider->route)); ?>">
                <h1 class="hero-title"><?php echo e($homeSlider->title); ?></h1>
            </a>
            <p class="hero-desc">
                <?php echo $homeSlider->builderWord(); ?>

            </p>
        </div>

        <a class="hero-img" href="<?php echo e(route($homeSlider->route)); ?>">
            <img src="<?php echo e(asset($homeSlider->image)); ?>" alt="">
        </a>

    </div>

</section>
<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/livewire/partials/header.blade.php ENDPATH**/ ?>