<aside <?php echo e($attributes->merge([ 'class' => 'post-right-side' ])); ?>>
    Aside right
</aside>

<?php /**PATH /home/anh/DEV/www/trillfa/resources/views/components/post-right-slide.blade.php ENDPATH**/ ?>