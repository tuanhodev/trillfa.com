<?php return array (
  'cagilo/cagilo' => 
  array (
    'providers' => 
    array (
      0 => 'Cagilo\\UI\\CagiloServiceProvider',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/scout' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Scout\\ScoutServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'orchid/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Icons\\IconServiceProvider',
    ),
  ),
  'orchid/platform' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Platform\\Providers\\FoundationServiceProvider',
    ),
    'aliases' => 
    array (
      'Alert' => 'Orchid\\Support\\Facades\\Alert',
      'Dashboard' => 'Orchid\\Support\\Facades\\Dashboard',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-markdown' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelMarkdown\\MarkdownServiceProvider',
    ),
  ),
  'tabuna/breadcrumbs' => 
  array (
    'providers' => 
    array (
      0 => 'Tabuna\\Breadcrumbs\\BreadcrumbsServiceProvider',
    ),
    'aliases' => 
    array (
      'Breadcrumbs' => 'Tabuna\\Breadcrumbs\\Breadcrumbs',
    ),
  ),
  'watson/active' => 
  array (
    'providers' => 
    array (
      0 => 'Watson\\Active\\ActiveServiceProvider',
    ),
    'aliases' => 
    array (
      'Active' => 'Watson\\Watson\\Facades\\Active',
    ),
  ),
);